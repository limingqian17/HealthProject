// app.js
App({
    globalData:{
        sessionid:'',
        username:'',
        useravavatar:'',
        userarea:'',
        userdate:'',
        userid:''
    }
})