// pages/forest/forest.js
import request from "../../utils/request";
Page({

    /**
     * 页面的初始数据
     */
    data: {
        charts:[],
        sum:0,
        all:0,
        username:'',
        useravatar:'',
        treecount:0,
        dialogShow: false,
        showOneButtonDialog: false,
        oneButton: [{ text: '确定' }]
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getDataFromServer();
        console.log("loding");
    },
    toIndex:function(opotions){
        wx.navigateBack({
            delta: 1
          })
    },
    async getDataFromServer(){
        let result=await request('http://47.120.14.52:8081/all');
        console.log(result);
        this.setData({charts:result});
        this.sumTree();
    },
    sumTree:function(opotions){
        let that=this
        let sum=that.data.sum
        let charts=that.data.charts
        for(let i = 0; i < charts.length; i++) {
            sum=sum+charts[i].treecount
        }
        console.log(sum)
        that.setData({
            all:sum
        })
        console.log(that.data.all)
    },
    showTree:function(opotions){
        // 定义一个数组
        var charts = this.data.charts;
        // 生成一个随机的索引值
        var index = Math.floor(Math.random() * charts.length);
        // 使用索引值获取数组中对应位置的元素
        var element = charts[index];
       // 打印结果
        console.log(element);
        this.setData({
            username:element.username,
            useravatar:element.useravatar,
            treecount:element.treecount
        })
    },
    tapDialogButton(e) {
        this.setData({
            dialogShow: false,
            showOneButtonDialog: false
        })
    },
    tapOneDialogButton(e) {
        this.setData({
            showOneButtonDialog: true
        });
        this.showTree();
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
        
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        let that=this
        that.setData({
        all:that.data.sum
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})