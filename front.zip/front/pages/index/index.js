// index.js
import request from "../../utils/request";
const app=getApp()
Page({
    data:{
        charts:[],
        sessionid:'',
        username:'',
        useravatar:'',
        userid:'',
        id:0,
        treecount:0,
        sum:0,
        all:0

    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.getDataFromServer();
        this.postS();
        console.log(this.data.all);
        
    },
    async getDataFromServer(){
        let result=await request('http://47.120.14.52:8081/all');
        console.log(result);
        this.setData({charts:result});
        this.sumTree();
    },
    sumTree:function(opotions){
        let that=this
        let sum=that.data.sum
        let charts=that.data.charts
        for(let i = 0; i < charts.length; i++) {
            sum=sum+charts[i].treecount
        }
        console.log(sum)
        that.setData({
            sum:sum,
            all:sum
        })
        console.log(that.data.all)
    },
    postS:function(opotions) {
        console.log(app.globalData.sessionid),
        this.setData({
            sessionid:app.globalData.sessionid,
        })
        console.log(this.data.sessionid)
        
    },
    toCharts:function(opotions){
        wx.navigateTo({
          url: '../charts/charts',
        })
    },
    toForest:function(opotions){
        wx.navigateTo({
          url: '../forest/forest',
        })
    },
    toClock:function(opotions){
        wx.navigateTo({
          url: '../clock/clock',
        })
    },
    toActivity:function(opotions){
        wx.navigateTo({
          url: '../activity/activity',
        })
    },
    onShow() {
        let that=this
        that.setData({
            username:app.globalData.username,
            useravatar:app.globalData.useravatar,
            sessionid:app.globalData.sessionid,
            userid:app.globalData.userid,
        })
        console.log(that.data.all)
    },
})

