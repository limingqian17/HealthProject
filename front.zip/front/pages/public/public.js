// pages/public/public.js
const app=getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        sessionid:'',
        useravatar:'',
        username:'',
		userid:'',
        type:'',
        text:'',
		items: [
			{ name: 'pl', value: '光盘' },
			{ name: 'fd', value: '饮食' },
			{ name: 'ru', value: '垃圾' },
			{ name: 'tr', value: '出行' },
			{ name: 'el', value: '其他',checked: 'true' },
          ],
        files: [],
        actionSheetItems: ['删除图片'],
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.setData({
            sessionid:app.globalData.sessionid,
            username:app.globalData.username,
            useravatar:app.globalData.useravatar,
            userid:app.globalData.userid
        })
	},
	radioChange: function (e) {
		console.log('radio发生change事件，携带value值为：', e.detail.value)
		this.data.type=e.detail.value
		console.log(this.data.type)
	 	switch(e.detail.value){
		  case 'pl':
			wx.showToast({
			  title: '光盘打卡',
			});
			break;
		  case 'fd':
			wx.showToast({
			  title: '饮食分享',
			});
			break;
		  case 'ru':
			wx.showToast({
			  title: '垃圾卫士',
			});
			break;
			case 'tr':
			wx.showToast({
			  title: '低碳出行',
			});
			break;
			case 'el':
			wx.showToast({
			  title: '其他',
			});
			break;
			default:
			  wx.showToast({
				icon:'error',
				title: '选择类型',
			  });
		}/***/
      },
      bindTextAreaBlur: function(e) {
        console.log(e.detail.value)
        this.setData({
            text:e.detail.value,
        })
      },
    //选择图片
    chooseImage: function() { 
        let that = this; 
        wx.chooseImage({ 
          sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
          sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
           
            success(res) { 
                that.setData({ 
                  files: res.tempFilePaths 
                  }) 
              } 
          }) 
          that.uploadImage(); 
    }, 
    uploadImage: function() { 
      let that = this; 
      let files = that.data.files; 
      for (let i = 0; i < files.length; i++) 
      { 
          wx.uploadFile({ 
              url: 'http://47.120.14.52:8081/upload', 
              filePath: files[i], 
              name: 'image', 
              header: {
                  //  "Content-Type": "application/x-www-form-urlencoded"
                  "Content-Type": "multipart/form-data"
              }, 
              formData: {'user': 'test'},
              success(res) { 
                  console.log(res.data)
                  console.log('上传成功'); 
              },fail(res) { 
                  console.log('上传失败'); 
              } 
          }) 
      } 
    },
    previewImage: function(e){
	var index = e.currentTarget.dataset.index;
      var infoImgList = this.data.files;
      wx.previewImage({
        current: infoImgList[index],  //当前图片地址
        urls: infoImgList, //所有要预览图片的地址集合 数组形式
      })
    },
    deleteImage: function (e) {
    var that = this;
    var files = that.data.files;
    var index = e.currentTarget.dataset.index;//获取当前长按图片下标
    wx.showActionSheet({
        itemList: this.data.actionSheetItems,
        success: function (res) {
          switch (res.tapIndex) {
            case 0: 
              // 选项1的功能实现
              console.log(0)
              files.splice(index, 1);
              that.setData({
                files
              });
              break;
              case 1: 
              // 选项1的功能实现
              console.log(1)
              files.splice(index, 1);
              break;  
          }
        },
        fail: function (res) {
          console.log(res)
        }
      })
   },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        this.setData({
            sessionid:app.globalData.sessionid,
            username:app.globalData.username,
            useravatar:app.globalData.useravatar,
            userid:app.globalData.userid
        })
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})